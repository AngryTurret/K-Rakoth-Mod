function init()
   effect.addStatModifierGroup({{stat = "atprk_4ddistortionResistance", amount = 0.25}, {stat = "atprk_4ddistortionStatusImmunity", amount = 1}})

   script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()
  
end
